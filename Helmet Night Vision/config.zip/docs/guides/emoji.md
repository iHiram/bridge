---
name: Emojis
---

# General Icons:

:armor: - `:armor:` 

:food: - `:food:` 

:minecoin: - `:minecoin:` 

:token: - `:token:` 

:agent: - `:agent:` 

:immersive_reader: - `:immersive_reader:` 

:craft_toggle_on: - `:craft_toggle_on:` 

:craft_toggle_off: - `:craft_toggle_off:` 


# Mobile Icons:

:mobile_jump: - `:mobile_jump:`

:mobile_crouch: - `:mobile_crouch:` 

:mobile_fly_up: - `:mobile_fly_up:` 

:mobile_fly_down: - `:mobile_fly_down:` 

:mobile_left_arrow: - `:mobile_left_arrow:` 

:mobile_right_arrow: - `:mobile_right_arrow:` 

:mobile_up_arrow: - `:mobile_up_arrow:` 

:mobile_down_arrow: - `:mobile_down_arrow:` 


# PC Icons:

:pc_left_click: - `:pc_left_click:` 

:pc_right_click: - `:pc_right_click:` 

:pc_middle_click: - `:pc_middle_click`


# Xbox Icons

:xbox_y: - `:xbox_y:`

:xbox_b: - `:xbox_b:`

:xbox_a: - `:xbox_a:`

:xbox_x: - `:xbox_x:`

:xbox_back: - `:xbox_back:`

:xbox_start: - `:xbox_start:`

:xbox_lb: - `:xbox_lb:`

:xbox_rb: - `:xbox_rb:`

:xbox_lt: - `:xbox_lt:`

:xbox_rt: - `:xbox_rt:`

:xbox_ls: - `:xbox_ls:`

:xbox_rs: - `:xbox_rs:`

:xbox_d_pad_up: - `:xbox_d_pad_up:`

:xbox_d_pad_right: - `:xbox_d_pad_right:`

:xbox_d_pad_down: - `:xbox_d_pad_down:`

:xbox_d_pad_left: - `:xbox_d_pad_left:`


# Nintendo Switch

:switch_x: - `:switch_x:`

:switch_a: - `:switch_a:`

:switch_b: - `:switch_b:`

:switch_y: - `:switch_y:`

:switch_+: - `:switch_+:`

:switch_-: - `:switch_-:`

:switch_l: - `:switch_l:`

:switch_r: - `:switch_r:`

:switch_zl: - `:switch_zl:`

:switch_rl: - `:switch_rl:`

:switch_l: - `:switch_l:`

:switch_r: - `:switch_r:`

:switch_d_pad_up: - `:switch_d_pad_up:`

:switch_d_pad_right: - `:switch_d_pad_right:`

:switch_d_pad_down: - `:switch_d_pad_down:`

:switch_d_pad_left: - `:switch_d_pad_left:`


# PS4 / PS5

:ps_triangle: - `:ps_triangle:`

:ps_circle: - `:ps_circle:`

:ps_cross: - `:ps_cross:`

:ps_square: - `:ps_square:`

:ps_options: - `:ps_options:`

:ps_touch_pad: - `:ps_touch_pad:`

:ps_l1: - `:ps_l1:`

:ps_r1: - `:ps_r1:`

:ps_l2: - `:ps_l2:`

:ps_r2: - `:ps_r2:`

:ps_l3: - `:ps_l3:`

:ps_r3: - `:ps_r3:`

:ps_d_pad_up: - `:ps_d_pad_up:`

:ps_d_pad_right: - `:ps_d_pad_right:`

:ps_d_pad_down: - `:ps_d_pad_down:`

:ps_d_pad_left:- `:ps_d_pad_left:`
